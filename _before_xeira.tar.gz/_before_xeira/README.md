# formiga-reactstrap

![formiga-reactstrap logo](https://formiga-reactstrap.afialapis.com/assets/images/logo/formiga-reactstrap_name.png)

[![NPM Version](https://badge.fury.io/js/formiga-reactstrap.svg)](https://www.npmjs.com/package/formiga-reactstrap)
[![Dependency Status](https://david-dm.org/afialapis/formiga-reactstrap.svg)](https://david-dm.org/afialapis/formiga-reactstrap)
[![NPM Downloads](https://img.shields.io/npm/dm/formiga-reactstrap.svg?style=flat)](https://www.npmjs.com/package/formiga-reactstrap)

A Reactstrap implementation of Formiga 