
const inputDefaultProps = {
  keepHeight: false,
  showValidity: 4,
  inline: false,
  bsSize: undefined
}

export {inputDefaultProps}