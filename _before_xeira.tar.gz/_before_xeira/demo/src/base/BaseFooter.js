import React from 'react'

const BaseFooter = () => 
  <footer>
    .
  </footer>

export {BaseFooter}