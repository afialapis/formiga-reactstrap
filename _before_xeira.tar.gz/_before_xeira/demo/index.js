import React from 'react'
import ReactDOM from 'react-dom'

import {Demo} from './src/Demo'


ReactDOM.render(<Demo/>, document.getElementById('content'));
